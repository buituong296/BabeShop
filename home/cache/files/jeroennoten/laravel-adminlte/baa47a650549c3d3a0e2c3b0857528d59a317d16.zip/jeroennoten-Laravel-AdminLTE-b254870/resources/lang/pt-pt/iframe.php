<?php

return [

    /*
    |--------------------------------------------------------------------------
    | IFrame Mode Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the AdminLTE IFrame mode blade
    | layout. You are free to modify these language lines according to your
    | application's requirements.
    |
    */

    'btn_close' => 'Fechar',
    'btn_close_active' => 'Fechar Ativo',
    'btn_close_all' => 'Fechar Todos',
    'btn_close_all_other' => 'Fechar Outros',
    'tab_empty' => 'Nenhum separador selecionado!',
    'tab_home' => 'Página Inicial',
    'tab_loading' => 'A carregar separador',

];
